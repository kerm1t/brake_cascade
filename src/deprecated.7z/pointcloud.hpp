#include "pointcloud_io.hpp"
#include "linmath.h"
#include <algorithm> // for some reason this need to be included in VStudio 2017

int colorcoding = 0;

int intensityclamp[2] = {0,4000};

// 2do: parameter -->
std::vector<float> vertices;
std::vector<float> colors[3]; // height, dist, intensity

// 2do: move this to a helper class
void hsv2rgb(const float h, const float s, const float v, float& r, float& g, float& b)
{
    const int   h_i = static_cast<int>(h * 6.0F);
    const float h_f = (h * 6.0F) - static_cast<float>(h_i);

    const float p = v * (1.0F - s);
    const float q = v * (1.0F - s * h_f);
    const float t = v * (1.0F - s * (1 - h_f));

    switch (h_i)
    {
    case 0:
    case 6:
    default:
        r = v;
        g = t;
        b = p;
        break;
    case 1:
        r = q;
        g = v;
        b = p;
        break;
    case 2:
        r = p;
        g = v;
        b = t;
        break;
    case 3:
        r = p;
        g = q;
        b = v;
        break;
    case 4:
        r = t;
        g = p;
        b = v;
        break;
    case 5:
        r = v;
        g = p;
        b = q;
        break;
    }
}

// b) load from .pcd or .bin
//point_cloud pointcloud_load(std::string s)
int pointcloud_load(std::string s)
{
  static const float COLOR_DISTANCE_MAX_INV = 1.0F / 250.0F;
//  static const float COLOR_AUTOSAR_HEIGHT_MIN = 0.0F;
  static const float COLOR_AUTOSAR_HEIGHT_MIN = -1.2F;
//  static const float COLOR_AUTOSAR_HEIGHT_MAX = 3.0F;
  static const float COLOR_AUTOSAR_HEIGHT_MAX = 3.5F;
  static const float FLOAT_TO_S16Q7 = 128.0F;
  static const float S16Q7_TO_FLOAT = 1.0F / FLOAT_TO_S16Q7;
  // convert coloring parameters from float to fixpoint
  static const float COLOR_AUTOSAR_HEIGHT_MIN_S16Q7 = COLOR_AUTOSAR_HEIGHT_MIN * FLOAT_TO_S16Q7;
  static const float COLOR_AUTOSAR_HEIGHT_MAX_S16Q7 = COLOR_AUTOSAR_HEIGHT_MAX * FLOAT_TO_S16Q7;
  static const float COLOR_DISTANCE_MAX_INV_S16Q7 = COLOR_DISTANCE_MAX_INV / FLOAT_TO_S16Q7;
  static const float COLOR_DISTANCE_MAX = 50.0f;

  std::cout << "clearing..." << std::endl;
///  p_cloud->clear();
  cloud.clear();
  vertices.clear();
  colors[0].clear();
  colors[1].clear();
  colors[2].clear();
  std::cout << "cleared" << std::endl;

  float loadtime = loadPointCloud(s, cloud); // returns load time in [sec], is < 0, if something failed
///  if (loadtime < 0) return point_cloud(0,-1);

  // 2do: copy over, simplify later
  for (int i = 0; i < cloud.size(); i++) // this for loop can be spared! MeasurmentPoint3D is proprietary, replace with PointXYZ
  {
    // (a) vertices
    PointXYZI pt;
    pt = cloud[i];
    vertices.push_back(pt.x);
    vertices.push_back(pt.y);
    vertices.push_back(pt.z);

    // (b) colors, precalc multiple colorizations (height, dist, intensity, ...)
    //     this needs 3 buffer objects on the gpu, alternative: fragment shader 
    float r,g,b;
    double hue;
    float height = (float)pt.z;
    float absDist = std::sqrt(pt.x * pt.x + pt.y * pt.y);

    hue = (1.0F - std::max<float>(COLOR_AUTOSAR_HEIGHT_MIN, std::min<float>(height, COLOR_AUTOSAR_HEIGHT_MAX)) / COLOR_AUTOSAR_HEIGHT_MAX) * (4.0F / 6.0F);
    hsv2rgb(hue, 1.0F, 1.0F, r, g, b);
    colors[0].push_back((float)b);
    colors[0].push_back((float)g);
    colors[0].push_back((float)r);

    hue = (1.0F - std::max<float>(0.0f, std::min<float>(absDist, COLOR_DISTANCE_MAX)) / COLOR_DISTANCE_MAX);
    hsv2rgb(hue, 1.0F, 1.0F, r, g, b);
    colors[1].push_back((float)b);
    colors[1].push_back((float)g);
    colors[1].push_back((float)r);

    int ilow = pt.intensity;
#define COLOR_LOWGAIN_MIN 0
#define COLOR_LOWGAIN_MAX 1000//5000
    //    double hue = (1.0F - std::max<float>(COLOR_LOWGAIN_MIN, std::min<float>(ilow, COLOR_LOWGAIN_MAX)) / COLOR_LOWGAIN_MAX);
    hue = (1.0F - std::max<float>(intensityclamp[0], std::min<float>(ilow, intensityclamp[1])) / intensityclamp[1]);
    hsv2rgb(hue, 1.0F, 1.0F, r, g, b);
    colors[2].push_back((float)b);
    colors[2].push_back((float)g);
    colors[2].push_back((float)r);
  }

  int numpoints = cloud.size();
	return numpoints;

//  return point_cloud(m_measPoints->size(), loadtime);
}

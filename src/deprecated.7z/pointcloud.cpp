#include <iostream>
#include <vector>
#define GLEW_STATIC                     // damit GLEW statisch gelinkt werden kann
#include <GL/glew.h>
#define SDL_MAIN_HANDLED                // eigene Hauptfunktion für SDL                                                                                                                                                                         #ifdef _WIN32                           // nur für Windows                                                              #include 

#ifdef _WIN32				// nur für Windows
#include <SDL.h>
#pragma comment(lib, "SDL2.lib")                          
#pragma comment(lib, "glew32s.lib")
#pragma comment(lib, "opengl32.lib")
#else
#include <SDL2/SDL.h>                   // Linux / MacOS  
#endif


#include <glm/vec3.hpp> // glm::vec3
#include <glm/vec4.hpp> // glm::vec4
#include <glm/mat4x4.hpp> // glm::mat4
#include <glm/ext/matrix_transform.hpp> // glm::translate, glm::rotate, glm::scale
#include <glm/ext/matrix_clip_space.hpp> // glm::perspective
#include <glm/ext/scalar_constants.hpp> // glm::pi


struct Vertex {
	float x;
	float y;
	float z;
};

int loadPCDFile(const std::string &filename, std::vector<Vertex> &cloud) // this can only read ASCII content files!, takes 0.8sec to load a 5MB .PCD (release build)
{
  FILE *f;
  char line[255];
  char tmp[55];
  char tmp2[55];
  char tmp3[55];
  float coord[4];
  bool bheader = true;

#ifdef _WIN32	
  fopen_s(&f, filename.c_str(), "r");
#else
  f = fopen(filename.c_str(), "r");
#endif
  while (fgets(line, sizeof(line), f))
  {
    if (bheader) sscanf(line, "%s %s %s", tmp, tmp2, tmp3);

    if (!bheader)
    {
      sscanf(line, "%f %f %f", &coord[0], &coord[1], &coord[2]);
      Vertex p;
      p.x = coord[0];
      p.y = coord[1];
      p.z = coord[2];
      cloud.push_back(p);
    }

    if (bheader)
      if (std::string(tmp) == "DATA")// && (std::string(tmp2) == "ascii")) // omitting the "ascii" seems considerably faster !?
        bheader = false;
  }
  fclose(f);
  return 0;
}

glm::mat4 camera(float Translate, glm::vec2 const& Rotate)
{
	glm::mat4 Projection = glm::perspective(glm::pi<float>() * 0.25f, 4.0f / 3.0f, 0.1f, 100.f);
	glm::mat4 View = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, -Translate));
	View = glm::rotate(View, Rotate.y, glm::vec3(-1.0f, 0.0f, 0.0f));
	View = glm::rotate(View, Rotate.x, glm::vec3(0.0f, 1.0f, 0.0f));
	glm::mat4 Model = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f));
	return Projection * View * Model;
}

int main(int argc, char** argv)
{
	// Fenster initialisieren
	SDL_Window* window;
	if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
		std::cout << "SDL_Init Error: " << SDL_GetError() << std::endl;
//		std::cin.get();
		return 1;
	}
	
	std::vector<Vertex> cloud;
	loadPCDFile("./bunny.pcd", cloud);
	
	// OpenGL initialisieren
	// Frame Buffer definieren
	SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);		// 8 bit für rot
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);		// 8 bit für grün
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);		// 8 bit für blau
	SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);		// 8 bit für alpha
	SDL_GL_SetAttribute(SDL_GL_BUFFER_SIZE, 32);	// 32 bit für Pixel (optional)
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);	// Double Buffering aktivieren

	// Fenster erzeugen
	window = SDL_CreateWindow("Point cloud viewer", SDL_WINDOWPOS_CENTERED,
		                   SDL_WINDOWPOS_CENTERED, 800, 600, SDL_WINDOW_OPENGL);
	SDL_GLContext glContext = SDL_GL_CreateContext(window);

	// GLEW initialisieren (Context muss bereits existieren)
	GLenum err = glewInit();
	if (err != GLEW_OK)
	{
		std::cout << "glewInit Error: " << glewGetErrorString(err) << std::endl;
		std::cin.get();
		return 2;
	}

	std::cout << "OpenGL version: " << glGetString(GL_VERSION) << std::endl;

        // die Eckpunkte des Dreiecks definieren
	Vertex vertices[] = {
		Vertex{-0.5f, -0.5f, 0.0f},
		Vertex{ 0.0f, 0.5f, 0.0f },
		Vertex{ 0.5f, -0.5f, 0.0f }
	};
	uint32_t numVertices = 3;

	// Buffer auf der Grafikkarte erstellen
///	GLuint vertexBuffer;
///	glGenBuffers(1, &vertexBuffer);
///	glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
///	glBufferData(GL_ARRAY_BUFFER, numVertices * sizeof(Vertex), vertices, GL_STATIC_DRAW);

	// OpenGL Vertex Format angeben
///	glEnableVertexAttribArray(0);
///	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), offsetof(struct Vertex, x));

    glVertexPointer(3, GL_FLOAT, sizeof(Vertex), &cloud);
 //   glColorPointer(3, GL_UNSIGNED_BYTE, sizeof(Vertex), &cloud[0].x); // r + size(3)
///    glDrawArrays(GL_POINTS, 0, static_cast<GLsizei>(cloud.size()));

//  glMatrixMode(GL_PROJECTION_MATRIX);
//  glLoadIdentity();
///  gluPerspective(60, (double)800*0.5 / (double)600, 0.1, 150);
	std::cout << cloud.size() << " points" << std::endl;
	
	// Game Loop
	bool close = false;
	do
	{
		// Buffer löschen (mit Farbe initialisieren)
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);	// mit welcher Farbe soll gelöscht werden?
		glClear(GL_COLOR_BUFFER_BIT);	        // Buffer löschen

///		glDrawArrays(GL_TRIANGLES, 0, numVertices);
		glDrawArrays(GL_POINTS, 0, static_cast<GLsizei>(cloud.size()));

		// Double Buffering (angezeigter Buffer tauschen)
		SDL_GL_SwapWindow(window);

		// Events abfragen
		SDL_Event event;
		while (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
			{
				close = true;
			}
		}
	} while (!close);

	SDL_Quit();
	return 0;
}
